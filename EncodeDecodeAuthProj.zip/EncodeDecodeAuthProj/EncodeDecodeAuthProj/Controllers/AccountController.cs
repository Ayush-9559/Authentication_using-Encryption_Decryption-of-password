﻿using EncodeDecodeAuthProj.Data;
using EncodeDecodeAuthProj.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging.Abstractions;
using System.Text;

namespace EncodeDecodeAuthProj.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext db;
        public AccountController(ApplicationDbContext db)
        {
            this.db = db;
        }

        public IActionResult Index()
        {
            var data = HttpContext.Session.GetString("Username");
            if(data != null)
            {
                var listdata = db.Utbls.ToList();
                ViewBag.Name = data;
                return View(listdata);
            }
            else
            {
                return RedirectToAction("Login", "Account");
            }
        }


        public static string EncryptPassword(string password)
        {
            if (string.IsNullOrEmpty(password))
            {
                return null;
            }
            else
            {
                byte[] data = ASCIIEncoding.ASCII.GetBytes(password);
                string ep = Convert.ToBase64String(data);
                return ep;
            }
        }
        public static string DecryptPassword(string password)
        {
            if (string.IsNullOrEmpty(password))
            {
                return null;
            }
            else
            {
                byte[] data = Convert.FromBase64String(password);
                string dp = ASCIIEncoding.ASCII.GetString(data);
                return dp;
            }
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Register(User u)
        {
            if (ModelState.IsValid)
            {
                var adduser = new User()
                {
                    Name = u.Name,
                    Email = u.Email,
                    Password = EncryptPassword(u.Password)
                };
                db.Utbls.Add(adduser);
                db.SaveChanges();
                TempData["Msg"] = "User Registered Succesfully !!!";
                return RedirectToAction("Login");
            }
            else
            {
                return View();
            }
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                var data = db.Utbls.Where(x=>x.Name.Equals(model.Username)).SingleOrDefault();
                if(data != null)
                {
                   bool d = data.Name.Equals(model.Username) && DecryptPassword(data.Password).Equals(model.Password);
                    if(d)
                    {
                        HttpContext.Session.SetString("Username", data.Name);
                        return RedirectToAction("Index", "Account");
                    }
                    else
                    {
                        TempData["Invalid"] = "Invalid Password !";
                        return View();
                    }
                }
            }
            else
            {
                TempData["InvalidEmail"] = "Invalid Username";
                return View();
            }
            return View();
        }

        [HttpPost]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
