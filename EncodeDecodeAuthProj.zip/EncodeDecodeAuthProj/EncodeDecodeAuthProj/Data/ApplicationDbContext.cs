﻿using EncodeDecodeAuthProj.Models;
using Microsoft.EntityFrameworkCore;

namespace EncodeDecodeAuthProj.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<User> Utbls { get; set; }
    }
}
